/** @file   fw_loader_uart.c
 *
 *  @brief  This file contains the functions that implement the Nxp specific
 *          Helper Protocol.
 *
 *  Copyright 2014-2022 NXP
 *
 *  NXP CONFIDENTIAL
 *  The source code contained or described herein and all documents related to
 *  the source code (Materials) are owned by NXP, its
 *  suppliers and/or its licensors. Title to the Materials remains with NXP,
 *  its suppliers and/or its licensors. The Materials contain
 *  trade secrets and proprietary and confidential information of NXP, its
 *  suppliers and/or its licensors. The Materials are protected by worldwide copyright
 *  and trade secret laws and treaty provisions. No part of the Materials may be
 *  used, copied, reproduced, modified, published, uploaded, posted,
 *  transmitted, distributed, or disclosed in any way without NXP's prior
 *  express written permission.
 *
 *  No license under any patent, copyright, trade secret or other intellectual
 *  property right is granted to or conferred upon you by disclosure or delivery
 *  of the Materials, either expressly, by implication, inducement, estoppel or
 *  otherwise. Any license under such intellectual property rights must be
 *  express and approved by NXP in writing.
 *
 */

/*===================== Include Files ============================================*/
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <memory.h>
#include <setjmp.h>
#include <malloc.h>
#include <errno.h>
#include <fcntl.h>
#include "fw_loader_uart.h"
#if (OS_TYPE == FW_LOADER_WIN)
#include "fw_loader_io_win.h"
#endif
#if (OS_TYPE == FW_LOADER_LINUX)
#include <termios.h>
#include <unistd.h>
#include "fw_loader_io_linux.h"
#endif
#include "fw_loader_frames.h"

/*===================== Macros ===================================================*/
#define VERSION_NUMBER      "350"
#define VERSION            "M" VERSION_NUMBER
#define MAX_LENGTH         0xFFFF	// Maximum 2 byte value
#define END_SIG_TIMEOUT    2500
#define MAX_CTS_TIMEOUT    500	// 500ms
#define TIMEOUT_VAL_MILLISEC  4000	// Timeout for getting 0xa5 or 0xaa or
					// 0xa7, 2 times of helper timeout
#define STRING_SIZE        6
#define HDR_LEN            16
#define CMD4               0x4
#define CMD6               0x6
#define CMD7               0x7

#define PRINT(...)         printf(__VA_ARGS__)

#define DOWNLOAD_SUCCESS                 0x0
#define OPEN_SERIAL_PORT_OR_FILE_ERROR   0x1
#define FEEK_SEEK_ERROR                  0x2
#define FILESIZE_IS_ZERO                 0x3
#define HEADER_SIGNATURE_TIMEOUT         0x4
#define READ_FILE_FAIL                   0x5
#define CHANGE_BAUDRATE_FAIL             0x6
#define CHANGE_TIMEOUT_VALUE_FAIL    0x7
#define OPEN_FILE_FAIL                   0x8
#define FILE_MODE_CANNOT_CHANGE          0X9
#define UNEXPECTED_BEHAVIOUR_IN_SETJMP   0xA
#define MALLOC_RETURNED_NULL             0xB

#define REQ_HEADER_LEN          1
#define A6REQ_PAYLOAD_LEN       8
#define AbREQ_PAYLOAD_LEN       3

#define END_SIG       0x005043

#define GP            0x107	/* x^8 + x^2 + x + 1 */
#define DI            0x07

#define CRC_ERR_BIT            1 << 0
#define NAK_REC_BIT            1 << 1
#define TIMEOUT_REC_ACK_BIT    1 << 2
#define TIMEOUT_REC_HEAD_BIT   1 << 3
#define TIMEOUT_REC_DATA_BIT   1 << 4
#define INVALID_CMD_REC_BIT    1 << 5
#define WIFI_MIC_FAIL_BIT      1 << 6
#define BT_MIC_FAIL_BIT        1 << 7

#define SWAPL(x) ((((x) >> 24) & 0xff) \
                 | (((x) >> 8) & 0xff00) \
                 | (((x) << 8) & 0xff0000L) \
                 | (((x) << 24) & 0xff000000L))

#define POLYNOMIAL 0x04c11db7L

#define CLKDIVAddr       0x7f00008f
#define UARTDIVAddr      0x7f000090
#define UARTMCRAddr      0x7f000091
#define UARTREINITAddr   0x7f000092
#define UARTICRAddr      0x7f000093
#define UARTFCRAddr      0x7f000094

#define MCR   0x00000022
#define INIT  0x00000001
#define ICR   0x000000c7
#define FCR   0x000000c7

static unsigned char crc8_table[256];	/* 8-bit table */
static int made_table = 0;

static unsigned long crc_table[256];
static BOOLEAN cmd7_Req = FALSE;
static BOOLEAN EntryPoint_Req = FALSE;
static uint32 change_baudrata_buffer_len = 0;
static uint32 cmd7_change_timeout_len = 0;

//CMD5 Header to change bootload baud rate 
static int8 m_Buffer_CMD5_Header[16] =
	{ 0x05, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x2c, 0x00, 0x00,
	0x00, 0x77, 0xdb, 0xfd, 0xe0
};

static int8 m_Buffer_CMD7_ChangeTimeoutValue[16] =
	{ 0x07, 0x00, 0x00, 0x00, 0x70, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x5b, 0x88, 0xf8, 0xba
};

static const UART_BAUDRATE UartCfgTbl[] = {
	{115200, 16, 0x0075F6FD},
	{3000000, 1, 0x00C00000},
	{4000000, 1, 0x01000000},
};

//#define DEBUG_PRINT
#define DEBUG_FRAME		/* Enabled by env: DUMP_FRAME=1 */

 /*==================== Typedefs =================================================*/

/*===================== Global Vars ==============================================*/

static SERIAL_INTERFACE *pSerialIf = NULL;
static SERIAL_CONFIG SerialCfg = { 0 };

// Maximum Length that could be asked by the Helper = 2 bytes 
static uint8 ucByteBuffer[MAX_LENGTH];

//Handler of File
static FILE *pFile;

// ID of the current com port
static int32 iPortID = OPEN_FAILURE;

// Size of the File to be downloaded
static long ulTotalFileSize = 0;

// Current size of the Download
static uint32 ulCurrFileSize = 0;
static uint32 ulLastOffsetToSend = 0xFFFF;
static BOOLEAN uiErrCase = FALSE;
static BOOLEAN uiReDownload = FALSE;
// Received Frame
static CTRL_FRAME sRxFrame;

// Transmitted Frame
static CTRL_FRAME sTxFrame;

static uint8 ucString[STRING_SIZE];

static BOOLEAN b16BytesData = FALSE;

static uint16 uiNewLen;
static uint32 ulNewOffset;
static uint16 uiNewError;

static uint8 uiProVer;
static BOOLEAN bVerChecked = FALSE;

typedef enum {
	Ver1,
	Ver2,
	Ver3,
} Version;

#ifdef DEBUG_PRINT
static uint8 uiErrCnt[16] = { 0 };
#endif

/*==================== Function Prototypes ======================================*/
static uint8 fw_upload_ComReadChar(int32 iPortID);
static int8 fw_upload_ComWriteChar(int32 iPortID, int8 iChar);
static int8 fw_upload_ComWriteChars(int32 iPortID, int8 * pChBuffer,
				    uint32 uiLen);
static int32 fw_upload_ComReadChars(int32 iPortID, int8 * pChBuffer,
				    int32 uiCount);

static void (*fw_upload_DelayInMs) (uint32 uiMs);
static uint64(*fw_upload_GetTime) (void);

static void fw_upload_gen_crc_table(void);
static unsigned long fw_upload_update_crc(unsigned long crc_accum,
					  char *data_blk_ptr,
					  int data_blk_size);
static void fw_upload_io_func_init(void);
static BOOLEAN fw_upload_lenValid(uint16 * uiLenToSend, uint8 * ucArray);
static void closeFileorDescriptor(int fileDescriptor);
static void init_crc8(void);

/*==================== Coded Procedures =========================================*/

/******************************************************************************

 *
 * Name: gen_crc_table
 *
 * Description:
 *   Genrate crc table    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
void
fw_upload_gen_crc_table()
{
	int i, j;
	unsigned long crc_accum;

	for (i = 0; i < 256; i++) {
		crc_accum = ((unsigned long)i << 24);
		for (j = 0; j < 8; j++) {
			if (crc_accum & 0x80000000L) {
				crc_accum = (crc_accum << 1) ^ POLYNOMIAL;
			} else {
				crc_accum = (crc_accum << 1);
			}
		}
		crc_table[i] = crc_accum;
	}

	return;
}

/******************************************************************************

 *
 * Name: update_crc
 *
 * Description:
 *   update the CRC on the data block one byte at a time    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   ata_blk_ptr:   the buffer pointer for updating crc.
 *   data_blk_size: the size of buffer
 *
 * Return Value:
 *   CRC value.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
unsigned long
fw_upload_update_crc(unsigned long crc_accum, char *data_blk_ptr,
		     int data_blk_size)
{
	unsigned long i, j;

	for (j = 0; j < data_blk_size; j++) {
		i = ((unsigned long)(crc_accum >> 24) ^ *data_blk_ptr++) & 0xff;
		crc_accum = (crc_accum << 8) ^ crc_table[i];
	}
	return crc_accum;
}

/******************************************************************************
 *
 * Name: fw_upload_io_func_init
 *
 * Description:
 *   This function initializes the IO function pointers.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
void
fw_upload_io_func_init()
{
// Initialize the function pointers depending
// on the OS type.
#if (OS_TYPE == FW_LOADER_WIN)
	fw_upload_DelayInMs = fw_upload_DelayInMs_Win;
	fw_upload_GetTime = fw_upload_GetTime_Win;
#else
	fw_upload_DelayInMs = fw_upload_DelayInMs_Linux;
	fw_upload_GetTime = fw_upload_GetTime_Linux;
#endif // (OS_TYPE == FW_LOADER_WIN)
}

static uint8
fw_upload_ComReadChar(int32 iPortID)
{
	uint8 iChar = 0xFF;	/* Failure value of fw_upload_ComReadChar_Xxx,
				   also an invalid value for RxFrame.header */
	iChar = pSerialIf->ComReadChar(iPortID);
#ifdef DEBUG_FRAME
	if (iChar != 0xFF && fw_upload_isDumpFrame()) {
		PRINT("\n%s Recv1: %02x ", fw_upload_getMsString(), iChar);
	}
#endif
	return iChar;
}

static int32
fw_upload_ComReadChars(int32 iPortID, int8 * pChBuffer, int32 uiCount)
{
	int32 iRead;
	iRead = pSerialIf->ComReadChars(iPortID, pChBuffer, uiCount);
#ifdef DEBUG_FRAME
	if (fw_upload_isDumpFrame()) {
		PRINT("\r%s Recv%d: %02x... ", fw_upload_getMsString(), iRead,
		      pChBuffer[0]);
	}
#endif
	return iRead;
}

static int8
fw_upload_ComWriteChar(int32 iPortID, int8 iChar)
{
	int8 iRet;
	iRet = pSerialIf->ComWriteChar(iPortID, iChar);
	return iRet;
}

static int8
fw_upload_ComWriteChars(int32 iPortID, int8 * pChBuffer, uint32 uiLen)
{
	int8 iRet;
	iRet = pSerialIf->ComWriteChars(iPortID, pChBuffer, uiLen);
	return iRet;
}

/******************************************************************************
 *
 * Name: init_crc8
 *
 * Description:
 *   This function init crc.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static void
init_crc8()
{
	int i, j;
	// unsigned char crc;
	int crc;
	if (!made_table) {
		for (i = 0; i < 256; i++) {
			crc = i;
			for (j = 0; j < 8; j++)
				crc = (crc << 1) ^ ((crc & 0x80) ? DI : 0);
			crc8_table[i] =
				(unsigned char)((unsigned char)crc &
						(unsigned char)0xFF);
			/* printf("table[%d] = %d (0x%X)\n", i, crc, crc); */
		}
		made_table = 1;
	}
}

/******************************************************************************
 *
 * Name: crc8
 *
 * Description:
 *   This function calculate crc.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   array: array to be calculated.
 *   len :  len of array.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static unsigned char
crc8(unsigned char *array, unsigned char len)
{
	unsigned char CRC = 0xff;
	for (; len > 0; len--) {
		CRC = crc8_table[CRC ^ *array];
		array++;
	}
	return CRC;
}

/******************************************************************************
 *
 * Name: fw_upload_WaitForHeaderSignature(uint32 uiMs)
 *
 * Description:
 *   This function basically waits for reception
 *   of character 0xa5 on UART Rx. If no 0xa5 is 
 *   received, it will kind of busy wait checking for
 *   0xa5.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   uiMs:   the expired time.
 *
 * Return Value:
 *   TRUE:   0xa5 or 0xab is received.
 *   FALSE:  0xa5 or 0xab is not received.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static BOOLEAN
fw_upload_WaitForHeaderSignature(uint32 uiMs)
{
	uint8 ucDone = 0;	// signature not Received Yet.
	uint64 startTime = 0;
	uint64 currTime = 0;
	BOOLEAN bResult = TRUE;
	startTime = fw_upload_GetTime();
	while (!ucDone) {
		sRxFrame.header = fw_upload_ComReadChar(iPortID);
		if ((sRxFrame.header == V1_HEADER_DATA_REQ) ||
		    (sRxFrame.header == V1_START_INDICATION) ||
		    (sRxFrame.header == V3_START_INDICATION) ||
		    (sRxFrame.header == V3_HEADER_DATA_REQ)) {
			ucDone = 1;
#ifdef DEBUG_PRINT
			PRINT("\nReceived 0x%x ", sRxFrame.header);
#endif
			if (!bVerChecked) {
				if ((sRxFrame.header == V1_HEADER_DATA_REQ) ||
				    (sRxFrame.header == V1_START_INDICATION)) {
					uiProVer = (uint8) Ver1;
				} else {
					uiProVer = (uint8) Ver3;
				}
				bVerChecked = TRUE;
			}
		} else {
#ifdef DEBUG_FRAME
			if (sRxFrame.header != 0xFF && fw_upload_isDumpFrame()) {
				PRINT("=> Unknown header(%02x)",
				      sRxFrame.header);
			}
#endif
			if (uiMs) {
				currTime = fw_upload_GetTime();
				if (currTime - startTime > uiMs) {
					bResult = FALSE;
					break;
				}
			}
			fw_upload_DelayInMs(1);
		}
	}
	return bResult;
}

/******************************************************************************
 *
 * Name: fw_upload_WaitFor_Len
 *
 * Description:
 *   This function waits to receive the 4 Byte length.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   pFile: The handler of file
 *
 * Return Value:
 *   2 Byte Length to send back to the Helper.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static uint16
fw_upload_WaitFor_Len(FILE * pFile_lcl)
{
	int8 bWriteStatus;
	// Length Variables
	// uint16 uiLen=0x0;
	// uint16 uiLenComp=0x0;
	// uiLen and uiLenComp are 1's complement of each other. 
	// In such cases, the XOR of uiLen and uiLenComp will be all 1's
	// i.e 0xffff.
	uint16 uiXorOfLen = 0xFFFF;

	// Read the Lengths.
	fw_upload_ComReadChars(iPortID, (int8 *) & sRxFrame.dataReqV1,
			       sizeof(sRxFrame.dataReqV1));
#ifdef DEBUG_FRAME
	fw_upload_dumpCtrlFrame(RX_DIR, &sRxFrame,
				sizeof(sRxFrame.header) +
				sizeof(sRxFrame.dataReqV1), "");
#endif

	// Check if the length is valid.
	if ((sRxFrame.dataReqV1.uiLen ^ sRxFrame.dataReqV1.uiLenComp) == uiXorOfLen)	// All 
		// 
		// 1's
	{
#ifdef DEBUG_PRINT
		PRINT("\n       bootloader asks for %d bytes \n ", uiLen);
#endif
		// Successful. Send back the ack.
		if ((sRxFrame.header == V1_HEADER_DATA_REQ) ||
		    (sRxFrame.header == V1_START_INDICATION)) {
			sTxFrame.header = V1_REQUEST_ACK;
			bWriteStatus =
				fw_upload_ComWriteChar(iPortID,
						       sTxFrame.header);
#ifdef DEBUG_FRAME
			fw_upload_dumpCtrlFrame(TX_DIR, &sTxFrame,
						sizeof(sTxFrame.header),
						(bWriteStatus) ? ("(write ok)")
						: ("(write error)"));
#endif
			if (sRxFrame.header == V1_START_INDICATION) {
				/* Eliminated longjmp(resync, 1); returning
				   restart status */
				return (uint16) V1_START_INDICATION;
			}
		}
	} else {
#ifdef DEBUG_PRINT
		PRINT("\n    NAK case: bootloader LEN = %x bytes \n ",
		      sRxFrame.dataReqV1.uiLen);
		PRINT("\n    NAK case: bootloader LENComp = %x bytes \n ",
		      sRxFrame.dataReqV1.uiLenComp);
#endif
		// Failure due to mismatch.  
		sTxFrame.header = V1_ERROR_ACK;
		bWriteStatus = fw_upload_ComWriteChar(iPortID, sTxFrame.header);
#ifdef DEBUG_FRAME
		fw_upload_dumpCtrlFrame(TX_DIR, &sTxFrame,
					sizeof(sTxFrame.header),
					(bWriteStatus) ? ("(write ok)")
					: ("(write error)"));
#endif
		// Start all over again.
		if (pFile_lcl != NULL) {
			/* Eliminated longjmp(resync, 1); returning restart
			   status */
			return (uint16) V1_START_INDICATION;
		} else {
			sRxFrame.dataReqV1.uiLen = 0;
		}
	}
	return sRxFrame.dataReqV1.uiLen;
}

/******************************************************************************
 *
 * Name: fw_upload_Send_Ack
 *
 * Description:
 *   This function sends ack to per req.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   uiAck: the ack type.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static void
fw_upload_Send_Ack(uint8 uiAck)
{
	int8 bWriteStatus;

	if ((uiAck == V3_REQUEST_ACK) || (uiAck == V3_CRC_ERROR)) {
		// prepare data & crc for 0x7A or 0x7C
		sTxFrame.header = uiAck;
		sTxFrame.ackNakV3.uiCrc =
			crc8((uint8 *) & sTxFrame,
			     sizeof(sTxFrame.header) +
			     sizeof(sTxFrame.ackNakV3) - 1);
		bWriteStatus =
			fw_upload_ComWriteChars(iPortID, (int8 *) & sTxFrame,
						sizeof(sTxFrame.header) +
						sizeof(sTxFrame.ackNakV3));
#ifdef DEBUG_FRAME
		fw_upload_dumpCtrlFrame(TX_DIR, &sTxFrame,
					sizeof(sTxFrame.header) +
					sizeof(sTxFrame.ackNakV3),
					(bWriteStatus) ? ("(write ok)")
					: ("(write error)"));
#endif
	} else if (uiAck == V3_TIMEOUT_ACK) {
		// prepare data & crc for 0x7B
		sTxFrame.header = uiAck;
		sTxFrame.timeoutV3.ulOffset = ulNewOffset;
		sTxFrame.timeoutV3.uiCrc =
			crc8((uint8 *) & sTxFrame,
			     sizeof(sTxFrame.header) +
			     sizeof(sTxFrame.timeoutV3) - 1);
		bWriteStatus =
			fw_upload_ComWriteChars(iPortID, (int8 *) & sTxFrame,
						sizeof(sTxFrame.header) +
						sizeof(sTxFrame.timeoutV3));
#ifdef DEBUG_FRAME
		fw_upload_dumpCtrlFrame(TX_DIR, &sTxFrame,
					sizeof(sTxFrame.header) +
					sizeof(sTxFrame.timeoutV3),
					(bWriteStatus) ? ("(write ok)")
					: ("(write error)"));
#endif
	} else {
		PRINT("\nNon-empty else statement\n");
	}

#ifdef DEBUG_PRINT
	PRINT("\n ===> ACK = %x, CRC = %x \n", uiAck, uiAckCrc);
#endif
}

/******************************************************************************
 *
 * Name: fw_upload_WaitFor_Req
 *
 * Description:
 *   This function waits for req from bootcode or helper.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static BOOLEAN
fw_upload_WaitFor_Req(int32 iSecondBaudRate)
{
	uint32 ulRxCnt;
	BOOLEAN bCrcMatch = FALSE;
	BOOLEAN status = TRUE;

	if (sRxFrame.header == V3_HEADER_DATA_REQ) {
		// 0xA7 <LEN><Offset><ERR><CRC8>
		for (ulRxCnt = 0; ulRxCnt < sizeof(sRxFrame.dataReqV3);) {
			int8 *pBuf = (int8 *) & sRxFrame.dataReqV3;

			ulRxCnt +=
				fw_upload_ComReadChars(iPortID, pBuf + ulRxCnt,
						       sizeof
						       (sRxFrame.dataReqV3) -
						       ulRxCnt);

			// TODO: how to manage timeout??
		}
#ifdef DEBUG_PRINT
		PRINT("\n <=== REQ = 0xA7, Len = %x,Off = %x,Err = %x,CRC = %x\n ", sRxFrame.dataReqV3.uiLen, sRxFrame.dataReqV3.ulOffset, sRxFrame.dataReqV3.uiError, sRxFrame.dataReqV3.uiCrc);
#endif
		// check crc
		bCrcMatch =
			(sRxFrame.dataReqV3.uiCrc ==
			 crc8((uint8 *) & sRxFrame,
			      sizeof(sRxFrame.header) +
			      sizeof(sRxFrame.dataReqV3) - 1));
#ifdef DEBUG_FRAME
		fw_upload_dumpCtrlFrame(RX_DIR, &sRxFrame,
					ulRxCnt + sizeof(sRxFrame.header),
					(bCrcMatch) ? ("(crc ok)")
					: ("(crc error)"));
#endif

		if (!bCrcMatch) {
#ifdef DEBUG_PRINT
			PRINT("\n === REQ = 0xA7, CRC Mismatched === ");
#endif
			fw_upload_Send_Ack(V3_CRC_ERROR);
			status = FALSE;

		} else {
			// Store new values
			uiNewLen = sRxFrame.dataReqV3.uiLen;
			ulNewOffset = sRxFrame.dataReqV3.ulOffset;
			uiNewError = sRxFrame.dataReqV3.uiError;

		}
	} else if (sRxFrame.header == V3_START_INDICATION) {
		// 0xAB <CHIP ID> <SW loader REV 1 byte> <CRC8>
		for (ulRxCnt = 0; ulRxCnt < sizeof(sRxFrame.startIndV3);) {
			int8 *pBuf = (int8 *) & sRxFrame.startIndV3;

			ulRxCnt +=
				fw_upload_ComReadChars(iPortID, pBuf + ulRxCnt,
						       sizeof
						       (sRxFrame.startIndV3) -
						       ulRxCnt);

			// TODO: how to manage timeout??
		}
#ifdef DEBUG_FRAME
		if (!fw_upload_isDumpFrame())
#endif
		{
			PRINT("\nChipID is : %x, Version is : %x\n",
			      sRxFrame.startIndV3.uiChipId,
			      sRxFrame.startIndV3.uiLoaderVer);
		}
		// check crc
		bCrcMatch =
			(sRxFrame.startIndV3.uiCrc ==
			 crc8((uint8 *) & sRxFrame,
			      sizeof(sRxFrame.header) +
			      sizeof(sRxFrame.startIndV3) - 1));
#ifdef DEBUG_FRAME
		fw_upload_dumpCtrlFrame(RX_DIR, &sRxFrame,
					ulRxCnt + sizeof(sRxFrame.header),
					(bCrcMatch) ? ("(crc ok)")
					: ("(crc error)"));
#endif

		if (bCrcMatch) {
#ifdef DEBUG_PRINT
			PRINT("\n === REQ = 0xAB, CRC Matched === ");
#endif
			fw_upload_Send_Ack(V3_REQUEST_ACK);
			if (iSecondBaudRate == 0) {
				/* longjmp(resync, 1); eliminated and added
				   return false to start again */
				return FALSE;
			}
		} else {
#ifdef DEBUG_PRINT
			PRINT("\n === REQ = 0xAB, CRC Mismatched === ");
#endif
			fw_upload_Send_Ack(V3_CRC_ERROR);
			status = FALSE;
			if (iSecondBaudRate == 0) {
				/* longjmp(resync, 1); eliminated and added
				   return false to start again */
				return FALSE;
			}
		}
	} else {
		PRINT("\nNon-empty else statement\n");
	}
	return status;
}

/******************************************************************************
 *
 * Name: fw_upload_GetCmd
 *
 * Description:
 *   This function gets CMD value in the header.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   *buf: buffer that stores header and following data.
 *
 * Return Value:
 *   CMD value part in the buffer.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static uint32
fw_upload_GetCmd(uint8 * buf)
{
	return (buf[0] | (buf[1] << 8) | (buf[2] << 16) | (buf[32] << 24));
}

/******************************************************************************
 *
 * Name: fw_upload_GetDataLen
 *
 * Description:
 *   This function gets buf data length.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   *buf: buffer that stores header and following data.
 *
 * Return Value:
 *   length of data part in the buffer.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static uint16
fw_upload_GetDataLen(uint8 * buf)
{
	return (buf[8] | (buf[9] << 8));
}

/******************************************************************************
 *
 * Name: fw_upload_lenValid
 *
 * Description:
 *   This function validates the length from 5 bytes request.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   ucArray: store the 5 bytes request.
 *
 * Return Value:
 *   uiLenToSend: if the length is valid, get value from ucArray.
 *
 * Notes:
 *   None.
 *
 
*****************************************************************************/
BOOLEAN
fw_upload_lenValid(uint16 * uiLenToSend, uint8 * ucArray)
{
	uint16 uiLen, uiLenComp;
	uint16 uiXorOfLen = 0xFFFF;
	uiLen = (uint16) ((ucArray[1] & 0xFF) | ((ucArray[2] << 8) & 0xFF00));
	uiLenComp =
		(uint16) ((ucArray[3] & 0xFF) | ((ucArray[4] << 8) & 0xFF00));
	// LEN valid if len & complement match
	if ((uiLen ^ uiLenComp) == uiXorOfLen)	// All 1's
	{
		*uiLenToSend = uiLen;
		return TRUE;
	} else {
		return FALSE;
	}
}

/******************************************************************************
 *
 * Name: fw_upload_GetHeaderStartBytes
 *
 * Description:
 *   This function gets 0xa5 and it's following 4 bytes length.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 
*****************************************************************************/
static void
fw_upload_GetHeaderStartBytes(uint8 * ucStr)
{
	BOOLEAN ucDone = FALSE, ucStringCnt = 0;
	while (!ucDone) {
		sRxFrame.header = fw_upload_ComReadChar(iPortID);

		if (sRxFrame.header == V1_HEADER_DATA_REQ) {
			ucStr[ucStringCnt++] = sRxFrame.header;
			ucDone = TRUE;
#ifdef DEBUG_PRINT
			PRINT("\nReceived 0x%x\n ", sRxFrame.header);
#endif
		} else {
#ifdef DEBUG_FRAME
			if (sRxFrame.header != 0xFF && fw_upload_isDumpFrame()) {
				PRINT("=> Unknown header(%02x)",
				      sRxFrame.header);
			}
#endif
			fw_upload_DelayInMs(1);
		}
	}
	while (pSerialIf->ComGetBufferSize(iPortID) < 4) ;
	ucStringCnt += fw_upload_ComReadChars(iPortID, (int8 *) ucStr, 4);
}

/******************************************************************************
 *
 * Name: fw_upload_GetLast5Bytes
 *
 * Description:
 *   This function gets last valid request.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   *buf: buffer that stores header and following data.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 
*****************************************************************************/
static void
fw_upload_GetLast5Bytes(uint8 * buf)
{
	uint8 a5cnt, i;
	uint8 ucTemp[STRING_SIZE];
	uint16 uiTempLen = 0;
	uint16 len = 0;
	int32 fifosize;
	BOOLEAN alla5times = FALSE;

	// initialise 
	memset(ucString, 0x00, STRING_SIZE);

	fifosize = pSerialIf->ComGetBufferSize(iPortID);

	fw_upload_GetHeaderStartBytes(ucString);

	if (fw_upload_lenValid(&uiTempLen, ucString) == TRUE) {
		// Valid length recieved 
#ifdef DEBUG_PRINT
		PRINT("\n Valid length = %d \n", uiTempLen);
#endif
	}

	len = fw_upload_GetDataLen(buf);
	if ((fifosize < 6) && ((uiTempLen == HDR_LEN) || (uiTempLen == len))) {
#ifdef DEBUG_PRINT
		PRINT("=========>success case\n");
#endif
		uiErrCase = FALSE;
	} else			// start to get last valid 5 bytes
	{
#ifdef DEBUG_PRINT
		PRINT("=========>fail case\n");
#endif
		while (fw_upload_lenValid(&uiTempLen, ucString) == FALSE) {
			fw_upload_GetHeaderStartBytes(ucString);
			fifosize -= 5;
		}
#ifdef DEBUG_PRINT
		PRINT("Error cases 1, 2, 3, 4, 5...\n");
#endif
		if (fifosize > 5) {
			fifosize -= 5;
			do {
				do {
					a5cnt = 0;
					do {
						fw_upload_GetHeaderStartBytes
							(ucTemp);
						fifosize -= 5;
					} while ((fw_upload_lenValid
						  (&uiTempLen, ucTemp) == TRUE)
						 && (!alla5times) &&
						 (fifosize > 5));
					// if 5bytes are all 0xa5, continue to
					// clear 0xa5
					for (i = 0; i < 5; i++) {
						if (ucTemp[i] ==
						    V1_HEADER_DATA_REQ) {
							a5cnt++;
						}
					}
					alla5times = TRUE;
				} while (a5cnt == 5);
#ifdef DEBUG_PRINT
				PRINT("a5 count in last 5 bytes: %d\n", a5cnt);
#endif
				if (fw_upload_lenValid(&uiTempLen, ucTemp) ==
				    FALSE) {
					fw_upload_ComReadChars(iPortID,
							       (int8 *) &
							       ucTemp[a5cnt],
							       5 - a5cnt);
					if (a5cnt > 0) {
						memcpy(ucString,
						       &ucTemp[a5cnt - 1],
						       (5 -
							a5cnt) * sizeof(uint8));
					}
				} else {
					memcpy(ucString, ucTemp,
					       5 * sizeof(uint8));
				}
			} while (fw_upload_lenValid(&uiTempLen, ucTemp) ==
				 FALSE);
		}
		uiErrCase = TRUE;
	}
}

/******************************************************************************
 *
 * Name: fw_upload_SendBuffer
 *
 * Description:
 *   This function sends buffer with header and following data.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *      uiLenToSend: len of header request.
 *            ucBuf: the buf to be sent.
 *   uiHighBaudrate: send the buffer for high baud rate change.
 * Return Value:
 *   Returns the len of next header request.
 *
 * Notes:
 *   None.
 *
 
*****************************************************************************/
static uint16
fw_upload_SendBuffer(uint16 uiLenToSend, uint8 * ucBuf, BOOLEAN uiHighBaudrate)
{
	uint16 uiBytesToSend = HDR_LEN, uiFirstChunkSent = 0;
	uint16 uiDataLen = 0;
	uint8 ucSentDone = 0;
	BOOLEAN uiValidLen = FALSE;
	uint8 bWriteStatus;

	// Get data len
	uiDataLen = fw_upload_GetDataLen(ucBuf);
	// Send buffer
	while (!ucSentDone) {
		if (uiBytesToSend == uiLenToSend) {
			// All good
			if ((uiBytesToSend == HDR_LEN) && (!b16BytesData)) {
				if ((uiFirstChunkSent == 0) ||
				    ((uiFirstChunkSent == 1) &&
				     (uiErrCase == TRUE))) {
					// Write first 16 bytes of buffer
#ifdef DEBUG_PRINT
					PRINT("\n====>  Sending first chunk...\n");
					PRINT("\n====>  Sending %d bytes...\n",
					      uiBytesToSend);
#endif
					bWriteStatus =
						fw_upload_ComWriteChars(iPortID,
									(int8 *)
									ucBuf,
									uiBytesToSend);
#ifdef DEBUG_FRAME
					fw_upload_dumpDataFrame(TX_DIR,
								(uint8 *) ucBuf,
								uiBytesToSend,
								(bWriteStatus)
								? ("(write ok)")
								:
								("(write error)"));
#endif
					if (cmd7_Req == TRUE ||
					    EntryPoint_Req == TRUE) {
						uiBytesToSend = HDR_LEN;
						uiFirstChunkSent = 1;
					} else {
						uiBytesToSend = uiDataLen;
						uiFirstChunkSent = 0;
						if (uiBytesToSend == HDR_LEN) {
							b16BytesData = TRUE;
						}
					}
				} else {
					// Done with buffer
					ucSentDone = 1;
					break;
				}
			} else {
				// Write remaining bytes
#ifdef DEBUG_PRINT
				PRINT("\n====>  Sending %d bytes...\n",
				      uiBytesToSend);
#endif
				if (uiBytesToSend != 0) {
					bWriteStatus =
						fw_upload_ComWriteChars(iPortID,
									(int8 *)
									&
									ucBuf
									[HDR_LEN],
									uiBytesToSend);
#ifdef DEBUG_FRAME
					fw_upload_dumpDataFrame(TX_DIR,
								(uint8 *) &
								ucBuf[HDR_LEN],
								uiBytesToSend,
								(bWriteStatus)
								? ("(write ok)")
								:
								("(write error)"));
#endif
					uiFirstChunkSent = 1;
					// We should expect 16, then next block 
					// 
					// will start
					uiBytesToSend = HDR_LEN;
					b16BytesData = FALSE;
					if (uiHighBaudrate) {
						return 0;
					}
				} else	// end of bin download
				{
#ifdef DEBUG_PRINT
					PRINT("\n ========== Download Complete =========\n\n");
#endif
					return 0;
				}
			}
		} else {
			// Something not good
			if ((uiLenToSend & 0x01) == 0x01) {
				// some kind of error
				if (uiLenToSend == (HDR_LEN + 1)) {
					// Send first chunk again
#ifdef DEBUG_PRINT
					PRINT("\n1. Resending first chunk...\n");
#endif
					bWriteStatus =
						fw_upload_ComWriteChars(iPortID,
									(int8 *)
									ucBuf,
									(uiLenToSend
									 - 1));
#ifdef DEBUG_FRAME
					fw_upload_dumpDataFrame(TX_DIR, ucBuf,
								uiLenToSend - 1,
								(bWriteStatus)
								? ("(write ok)")
								:
								("(write error)"));
#endif
					uiBytesToSend = uiDataLen;
					uiFirstChunkSent = 0;
				} else if (uiLenToSend == (uiDataLen + 1)) {
					// Send second chunk again
#ifdef DEBUG_PRINT
					PRINT("\n2. Resending second chunk...\n");
#endif
					bWriteStatus =
						fw_upload_ComWriteChars(iPortID,
									(int8 *)
									&
									ucBuf
									[HDR_LEN],
									(uiLenToSend
									 - 1));
#ifdef DEBUG_FRAME
					fw_upload_dumpDataFrame(TX_DIR, ucBuf,
								uiLenToSend - 1,
								(bWriteStatus)
								? ("(write ok)")
								:
								("(write error)"));
#endif
					uiBytesToSend = HDR_LEN;
					uiFirstChunkSent = 1;
				} else {
					PRINT("\nNon-empty terminating else statement\n");
				}
			} else if (uiLenToSend == HDR_LEN) {
				// Out of sync. Restart sending buffer
#ifdef DEBUG_PRINT
				PRINT("\n3.  Restart sending the buffer...\n");
#endif
				bWriteStatus =
					fw_upload_ComWriteChars(iPortID,
								(int8 *) ucBuf,
								uiLenToSend);
#ifdef DEBUG_FRAME
				fw_upload_dumpDataFrame(TX_DIR, ucBuf,
							uiLenToSend,
							(bWriteStatus)
							? ("(write ok)")
							: ("(write error)"));
#endif
				uiBytesToSend = uiDataLen;
				uiFirstChunkSent = 0;
			} else {
				PRINT("\nNon-empty else statement\n");
			}
		}
		// Get last 5 bytes now
		fw_upload_GetLast5Bytes(ucBuf);
		// Get next length
		uiValidLen = FALSE;
		do {
			if (fw_upload_lenValid(&uiLenToSend, ucString) == TRUE) {
				// Valid length received
				uiValidLen = TRUE;
#ifdef DEBUG_PRINT
				PRINT("\n Valid length = %d \n", uiLenToSend);
#endif
				// ACK the bootloader
				sTxFrame.header = V1_REQUEST_ACK;
				bWriteStatus =
					fw_upload_ComWriteChar(iPortID,
							       sTxFrame.header);
#ifdef DEBUG_FRAME
				fw_upload_dumpCtrlFrame(TX_DIR, &sTxFrame,
							sizeof(sTxFrame.header),
							(bWriteStatus)
							? ("(write ok)")
							: ("(write error)"));
#endif
#ifdef DEBUG_PRINT
				PRINT("\n  BOOT_HEADER_ACK 0x5a sent \n");
#endif
			}
		} while (!uiValidLen);
	}
#ifdef DEBUG_PRINT
	PRINT("\n ========== Buffer is successfully sent =========\n\n");
#endif
	return uiLenToSend;
}

/******************************************************************************
 *
 * Name: fw_upload_V1SendLenBytes
 *
 * Description:
 *   This function sends Len bytes(header+data) to the boot code.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   pFileBuffer: bin file buffer being sent.
 *   uiLenTosend: the length will be sent.
 *
 * Return Value:
 *   the 'len' of next header request.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static uint16
fw_upload_V1SendLenBytes(uint8 * pFileBuffer, uint16 uiLenToSend)
{
	uint16 ucDataLen, uiLen;
	uint32 ulCmd;
#ifdef DEBUG_PRINT
	uint16 i;
#endif
	memset(ucByteBuffer, 0, sizeof(ucByteBuffer));

	cmd7_Req = FALSE;
	EntryPoint_Req = FALSE;
	// fread(void *buffer, size_t size, size_t count, FILE *stream)

	if (ulCurrFileSize + uiLenToSend > ulTotalFileSize)
		uiLenToSend = (uint16) (ulTotalFileSize - ulCurrFileSize);

	memcpy(&ucByteBuffer[uiLenToSend] - uiLenToSend,
	       pFileBuffer + ulCurrFileSize, uiLenToSend);
	ulCurrFileSize += uiLenToSend;
	ulCmd = fw_upload_GetCmd(ucByteBuffer);
	if (ulCmd == CMD7) {
		cmd7_Req = TRUE;
		ucDataLen = 0;
	} else {
		ucDataLen = fw_upload_GetDataLen(ucByteBuffer);
		memcpy(&ucByteBuffer[uiLenToSend], pFileBuffer + ulCurrFileSize,
		       ucDataLen);
		ulCurrFileSize += ucDataLen;
		if ((ulCurrFileSize < ulTotalFileSize) &&
		    (ulCmd == CMD6 || ulCmd == CMD4)) {
			EntryPoint_Req = TRUE;
		}
	}

#ifdef DEBUG_PRINT
	PRINT("The buffer is to be sent: %d", uiLenToSend + ucDataLen);
	for (i = 0; i < (uiLenToSend + ucDataLen); i++) {
		if (i % 16 == 0) {
			PRINT("\n");
		}
		PRINT(" %02x ", ucByteBuffer[i]);
	}
#endif
	// start to send Temp buffer
	uiLen = fw_upload_SendBuffer(uiLenToSend, ucByteBuffer, FALSE);
	PRINT("File downloaded: %8u:%8ld\r", ulCurrFileSize, ulTotalFileSize);

	return uiLen;
}

/******************************************************************************
 *
 * Name: fw_upload_V3SendLenBytes
 *
 * Description:
 *   This function sends Len bytes to the Helper.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   pFileBuffer: bin file buffer being sent.
 *   uiLenTosend: the length will be sent.
 *   ulOffset: the offset of current sending.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static void
fw_upload_V3SendLenBytes(uint8 * pFileBuffer, uint16 uiLenToSend,
			 uint32 ulOffset)
{
	int8 bWriteStatus;

	// Retransmittion of previous block
	if (ulOffset == ulLastOffsetToSend) {
#ifdef DEBUG_PRINT
		PRINT("\nResend offset %d...\n", ulOffset);
#endif
		bWriteStatus =
			fw_upload_ComWriteChars(iPortID, (int8 *) ucByteBuffer,
						uiLenToSend);
#ifdef DEBUG_FRAME
		fw_upload_dumpDataFrame(TX_DIR, ucByteBuffer, uiLenToSend,
					(bWriteStatus) ? ("(write ok)")
					: ("(write error)"));
#endif
	} else {

#ifdef DEBUG_PRINT
		PRINT("%s : pFileBuffer %p ulOffset %d change_baudrata_buffer_len %d \
           cmd7_change_timeout_len %d\n", __func__, pFileBuffer, ulOffset,
		      change_baudrata_buffer_len, cmd7_change_timeout_len);
#endif
		if (ulOffset <
		    (change_baudrata_buffer_len + cmd7_change_timeout_len)) {
			PRINT("%s: Something wrong during FW downloading, \
             please power cycling and execute fw_loader again\n", __func__);
			/* TODO: Power cycling implementation */
			exit(EIO);
		}
		// The length requested by the Helper is equal to the Block
		// sizes used while creating the FW.bin. The usual
		// block sizes are 128, 256, 512.
		// uiLenToSend % 16 == 0. This means the previous packet
		// was error free (CRC ok) or this is the first packet
		// received.
		// We can clear the ucByteBuffer and populate fresh data. 
		memset(ucByteBuffer, 0, MAX_LENGTH * sizeof(uint8));
		memcpy(ucByteBuffer,
		       pFileBuffer + ulOffset - change_baudrata_buffer_len -
		       cmd7_change_timeout_len, uiLenToSend);
		ulCurrFileSize =
			ulOffset - change_baudrata_buffer_len -
			cmd7_change_timeout_len + uiLenToSend;

		bWriteStatus =
			fw_upload_ComWriteChars(iPortID, (int8 *) ucByteBuffer,
						uiLenToSend);
#ifdef DEBUG_FRAME
		fw_upload_dumpDataFrame(TX_DIR, ucByteBuffer, uiLenToSend,
					(bWriteStatus) ? ("(write ok)")
					: ("(write error)"));
#endif

		ulLastOffsetToSend = ulOffset;
	}
}

/******************************************************************************
 *
 * Name: fw_Change_Baudrate
 *
 * Description:
 *   This function changes the baud rate of bootrom.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   pPortName:                  Serial port value.
 *   bFirstWaitHeaderSignature:  TBD.
 *
 * Return Value:
 *   TRUE:            Change baud rate successfully
 *   FALSE:           Change baud rate unsuccessfully
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static int32
fw_Change_Baudrate(int8 * pPortName, BOOLEAN bFirstWaitHeaderSignature)
{
	uint8 uartConfig[60];
	uint8 ucBuffer[80];
	uint32 j;
	uint32 uartClk = 0x00C00000;
	uint32 uartDiv = 0x1;
	uint16 uiLenToSend = 0;
	uint32 uiCrc = 0;
	uint32 uiLen = 0;
	BOOLEAN bRetVal = FALSE;
	int32 ucResult = -1;
	uint8 ucLoadPayload = 0;
	uint32 waitHeaderSigTime = 0;
	BOOLEAN uiReUsedInitBaudrate = FALSE;
	uint32 headLen = 0;
	BOOLEAN flag = FALSE;

	uint32 mcr = MCR;
	uint32 init = INIT;
	uint32 icr = ICR;
	uint32 fcr = FCR;
	uint32 brAddr = CLKDIVAddr;
	uint32 divAddr = UARTDIVAddr;
	uint32 mcrAddr = UARTMCRAddr;
	uint32 reInitAddr = UARTREINITAddr;
	uint32 icrAddr = UARTICRAddr;
	uint32 fcrAddr = UARTFCRAddr;
	int8 bWriteStatus;

	for (j = 0; j < sizeof(UartCfgTbl) / sizeof(UART_BAUDRATE); j++) {
		if (SerialCfg.uart.uiSecondBaudrate == UartCfgTbl[j].iBaudRate) {
			uartDiv = UartCfgTbl[j].iUartDivisor;
			uartClk = UartCfgTbl[j].iClkDivisor;
			ucResult = 0;
			break;
		}
	}

	if (ucResult != 0) {
		return ucResult;
	}

	if (iPortID == OPEN_FAILURE) {
		return RW_FAILURE;
	}
	// Generate CRC value for CMD5 payload
	memcpy(uartConfig + uiLen, &brAddr, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &uartClk, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &divAddr, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &uartDiv, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &mcrAddr, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &mcr, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &reInitAddr, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &init, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &icrAddr, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &icr, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &fcrAddr, 4);
	uiLen += 4;
	memcpy(uartConfig + uiLen, &fcr, 4);
	uiLen += 4;
	headLen = uiLen + 4;

	fw_upload_gen_crc_table();
	memcpy(m_Buffer_CMD5_Header + 8, &headLen, 4);
	uiCrc = (uint32) fw_upload_update_crc((unsigned long)0,
					      (char *)m_Buffer_CMD5_Header,
					      (int)12);
	uiCrc = (uint32) SWAPL(uiCrc);
	memcpy(m_Buffer_CMD5_Header + 12, &uiCrc, 4);
	uiCrc = (uint32) fw_upload_update_crc((unsigned long)0,
					      (char *)uartConfig, (int)uiLen);
	uiCrc = (uint32) SWAPL(uiCrc);
	memcpy(uartConfig + uiLen, &uiCrc, 4);
	uiLen += 4;

	while (!bRetVal) {
		if (ucLoadPayload != 0 || uiReUsedInitBaudrate) {
			waitHeaderSigTime = TIMEOUT_VAL_MILLISEC;
		} else {
			waitHeaderSigTime = 0;
		}
		// Wait to Receive 0xa5, 0xaa, 0xab, 0xa7
		// If the second baudrate is used, wait for 2s to check 0xa5
		flag = fw_upload_WaitForHeaderSignature(waitHeaderSigTime);
		if (bFirstWaitHeaderSignature && flag) {
			if (ucLoadPayload) {
				if (uiProVer == Ver3) {
					change_baudrata_buffer_len =
						(uint32) HDR_LEN +
						(uint32) uiNewLen;
				}
				break;
			}
		} else {
			if (uiReUsedInitBaudrate) {
				ucResult = -2;
				return ucResult;
			}
			if (ucLoadPayload) {
				// If 0xa5 or 0xa7 is not received by using the 
				// 
				// second baudrate, change baud rate to the
				// first baudrate.
				if (iPortID == OPEN_FAILURE) {
					return RW_FAILURE;
				}
				pSerialIf->Close(iPortID);

				if (pSerialIf->type == UART_IF) {
					SerialCfg.uiSpeed =
						SerialCfg.uart.uiFirstBaudrate;
				}
				iPortID =
					pSerialIf->Open(pPortName, &SerialCfg);
				if (iPortID == OPEN_FAILURE) {
					return RW_FAILURE;
				}
				ucLoadPayload = 0;
				uiReUsedInitBaudrate = TRUE;
				continue;
			}
		}
		if (uiProVer == Ver1) {
			uiLenToSend = fw_upload_WaitFor_Len(NULL);
			if (uiLenToSend == V1_START_INDICATION) {
				return (int32) V1_START_INDICATION;
			}
			if (uiLenToSend == 0) {
				continue;
			} else if (uiLenToSend == HDR_LEN) {
				// Download CMD5 header and Payload packet.
				memcpy(ucBuffer, m_Buffer_CMD5_Header, HDR_LEN);
				memcpy(ucBuffer + HDR_LEN, uartConfig, uiLen);
				fw_upload_SendBuffer(uiLenToSend, ucBuffer,
						     TRUE);
				pSerialIf->Close(iPortID);
				if (pSerialIf->type == UART_IF) {
					SerialCfg.uiSpeed =
						SerialCfg.uart.uiSecondBaudrate;
					SerialCfg.uart.ucFlowCtrl = 1;
				}
				iPortID =
					pSerialIf->Open(pPortName, &SerialCfg);
				if (iPortID == OPEN_FAILURE) {
					return RW_FAILURE;
				}
				ucLoadPayload = 1;
			} else {
				// Download CMD5 header and Payload packet
				bWriteStatus =
					fw_upload_ComWriteChars(iPortID,
								(int8 *)
								uartConfig,
								uiLen);
#ifdef DEBUG_FRAME
				fw_upload_dumpDataFrame(TX_DIR, uartConfig,
							uiLen, (bWriteStatus)
							? ("uartCfg (write ok)")
							:
							("uartCfg (write error)"));
#endif
				pSerialIf->Close(iPortID);
				if (pSerialIf->type == UART_IF) {
					SerialCfg.uiSpeed =
						SerialCfg.uart.uiSecondBaudrate;
					SerialCfg.uart.ucFlowCtrl = 1;
				}
				iPortID =
					pSerialIf->Open(pPortName, &SerialCfg);
				ucLoadPayload = 1;
			}
		} else if (uiProVer == Ver3) {
			flag = fw_upload_WaitFor_Req(pSerialIf->type == UART_IF
						     && SerialCfg.uart.
						     uiSecondBaudrate);
			if (!bFirstWaitHeaderSignature || flag) {
				if (uiNewLen != 0 &&
				    sRxFrame.header == V3_HEADER_DATA_REQ) {
					if (uiNewError == 0) {
						fw_upload_Send_Ack
							(V3_REQUEST_ACK);
						bFirstWaitHeaderSignature =
							TRUE;

						if (uiNewLen == HDR_LEN) {
							bWriteStatus =
								fw_upload_ComWriteChars
								(iPortID,
								 m_Buffer_CMD5_Header,
								 uiNewLen);
#ifdef DEBUG_FRAME
							fw_upload_dumpDataFrame
								(TX_DIR,
								 (uint8 *)
								 m_Buffer_CMD5_Header,
								 uiNewLen,
								 (bWriteStatus)
								 ?
								 ("(write ok)")
								 :
								 ("(write error)"));
#endif
						} else {
							bWriteStatus =
								fw_upload_ComWriteChars
								(iPortID,
								 (int8 *)
								 uartConfig,
								 uiNewLen);
#ifdef DEBUG_FRAME
							fw_upload_dumpDataFrame
								(TX_DIR,
								 uartConfig,
								 uiNewLen,
								 (bWriteStatus)
								 ?
								 ("uartCfg (write ok)")
								 :
								 ("uartCfg (write error)"));
#endif
							// Reopen Uart by using 
							// 
							// the second baudrate
							// after downloading
							// the payload.
							pSerialIf->Close
								(iPortID);
							if (pSerialIf->type ==
							    UART_IF) {
								SerialCfg.
									uiSpeed
									=
									SerialCfg.
									uart.
									uiSecondBaudrate;
								SerialCfg.uart.
									ucFlowCtrl
									= 1;
							}
							iPortID =
								pSerialIf->Open
								(pPortName,
								 &SerialCfg);
							ucLoadPayload = 1;
						}
					} else	// NAK,TIMEOUT,INVALID
						// COMMAND...
					{
						pSerialIf->Flush(iPortID);
						fw_upload_Send_Ack
							(V3_TIMEOUT_ACK);
					}
				}
			}
		} else {
			PRINT("\nNon-empty terminating else statement\n");
		}
	}
	return ucResult;
}

/******************************************************************************
 *
 * Name: fw_Change_Timeout
 *
 * Description:
 *   This function changes timeout value of boot loader
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   pPortName:       Com port number.

 * Return Value:
 *   the status  of changing timeout value
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static int32
fw_Change_Timeout(int8 * pPortName)
{

	int32 Status = -1;
	BOOLEAN bFirst = TRUE;
	BOOLEAN bRetVal = FALSE;
	uint8 reTryNumber = 0;
	int8 bWriteStatus;

	fw_upload_gen_crc_table();

	while (!bRetVal) {
		if (fw_upload_WaitForHeaderSignature(TIMEOUT_VAL_MILLISEC)) {
			if (uiProVer == Ver3) {
				if (fw_upload_WaitFor_Req(1)) {
					if (uiNewLen != 0) {
						if (uiNewError == 0) {
#ifdef DEBUG_PRINT
							PRINT("\n === Succ: REQ = 0xA7, Errcode = 0 ");
#endif
							if (bFirst ||
							    ulLastOffsetToSend
							    == ulNewOffset) {
								fw_upload_Send_Ack
									(V3_REQUEST_ACK);
								bWriteStatus =
									fw_upload_ComWriteChars
									(iPortID,
									 m_Buffer_CMD7_ChangeTimeoutValue,
									 uiNewLen);
#ifdef DEBUG_FRAME
								fw_upload_dumpDataFrame
									(TX_DIR,
									 (uint8
									  *)
									 m_Buffer_CMD7_ChangeTimeoutValue,
									 uiNewLen,
									 (bWriteStatus)
									 ?
									 ("(write ok)")
									 :
									 ("(write error)"));
#endif
								ulLastOffsetToSend
									=
									ulNewOffset;
								bFirst = FALSE;
							} else {
								bRetVal = TRUE;
								Status = 0;

							}
						} else {
							if (reTryNumber < 6) {
								pSerialIf->Flush
									(iPortID);
								fw_upload_Send_Ack
									(V3_TIMEOUT_ACK);
								reTryNumber++;
							} else {
								bRetVal = TRUE;
							}

						}
					}

				}

			}
			if (uiProVer == Ver1) {
				Status = 1;
				break;
			}

		} else {
			PRINT("Timeout for waiting header signature in fw_Change_Timeout function\n");
			return Status;
		}
	}
	return Status;
}

/******************************************************************************
 *
 * Name: fw_upload_FW
 *
 * Description:
 *   This function performs the task of FW load over UART.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   pPortName:       Com port number.
 *
 * Return Value:
 *   the error code of downloading
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static uint32
fw_upload_FW(int8 * pPortName)
{
	uint8 *pFileBuffer = NULL;
	uint16 uiLenToSend = 0;

	BOOLEAN bRetVal = 0;
	BOOLEAN flag = FALSE;
	int32 result = 0;

	uint32 ulReadLen = 0;

	BOOLEAN bFirstWaitHeaderSignature = TRUE;
	// UART specific variables

	if (uiReDownload == FALSE) {
		// UART Init
		if (pSerialIf->type == UART_IF) {
			SerialCfg.uiSpeed = SerialCfg.uart.uiFirstBaudrate;
		}
		iPortID = pSerialIf->Open(pPortName, &SerialCfg);
	}
	if ((iPortID == OPEN_FAILURE) || (pFile == NULL)) {
		PRINT("\nPort is not open or file not found\n");
		return OPEN_SERIAL_PORT_OR_FILE_ERROR;
	}

	result = fw_Change_Timeout(pPortName);
	if (result == 0) {
		cmd7_change_timeout_len = HDR_LEN;
		bFirstWaitHeaderSignature = FALSE;
	} else {
		return result;
	}

	if (pSerialIf->type == UART_IF && SerialCfg.uart.uiSecondBaudrate) {
		uint32 j = 0;
		result = fw_Change_Baudrate(pPortName,
					    bFirstWaitHeaderSignature);
		switch (result) {
		case -1:
			PRINT("\nSecond baud rate %d is not support\n",
			      SerialCfg.uart.uiSecondBaudrate);
			PRINT("\nFw loader only supports the baud rate as");
			for (j = 0;
			     j < sizeof(UartCfgTbl) / sizeof(UART_BAUDRATE);
			     j++) {
				PRINT(" %d ", UartCfgTbl[j].iBaudRate);
			}
			PRINT("\n");
			break;
		case -2:
			PRINT("\n0xa5 or 0xaa is not received after changing baud rate in 2s.\n");
			break;
		default:
			break;
		}
		if (result != 0) {
			return CHANGE_BAUDRATE_FAIL;
		}
	}
	// Calculate the size of the file to be downloaded. 
	result = fseek(pFile, 0, SEEK_END);
	if (result != 0) {
		PRINT("\nfseek failed\n");
		return FEEK_SEEK_ERROR;
	}

	ulTotalFileSize = (long)ftell(pFile);
	if (ulTotalFileSize <= 0) {
		PRINT("\nError:Download Size is 0\n");
		return FILESIZE_IS_ZERO;
	}
	pFileBuffer = (uint8 *) malloc((size_t) ulTotalFileSize);
	if (pFileBuffer == NULL) {
		PRINT("malloc() returned NULL while allocating size for file");
		return MALLOC_RETURNED_NULL;
	}

	result = fseek(pFile, 0, SEEK_SET);
	if (result != 0) {
		PRINT("\nfseek() failed");
		free(pFileBuffer);
		return FEEK_SEEK_ERROR;
	}

	if (pFileBuffer != (void *)0) {
		ulReadLen =
			(size_t) fread((void *)pFileBuffer, (size_t) 1,
				       (size_t) ulTotalFileSize, pFile);
		if (ulReadLen != ulTotalFileSize) {
			PRINT("\nError:Read File Fail\n");
			free(pFileBuffer);
			return READ_FILE_FAIL;
		}
	}
	ulCurrFileSize = 0;

	while (!bRetVal) {
		// Wait to Receive 0xa5, 0xaa, 0xab, 0xa7
		flag = fw_upload_WaitForHeaderSignature(TIMEOUT_VAL_MILLISEC);
		if (!
		    (pSerialIf->type == UART_IF &&
		     SerialCfg.uart.uiSecondBaudrate) && !flag) {
			PRINT("\n0xa5,0xaa,0xab or 0xa7 is not received in %d ms\n", TIMEOUT_VAL_MILLISEC);
			free(pFileBuffer);
			return HEADER_SIGNATURE_TIMEOUT;
		}

		if (uiProVer == Ver1) {
			// Read the 'Length' bytes requested by Helper
			uiLenToSend = fw_upload_WaitFor_Len(pFile);
			if (uiLenToSend == V1_START_INDICATION) {
				// restart again
				continue;
			}
			do {
				uiLenToSend =
					fw_upload_V1SendLenBytes(pFileBuffer,
								 uiLenToSend);
			} while (uiLenToSend != 0);
			// If the Length requested is 0, download is complete.
			if (uiLenToSend == 0) {
				bRetVal = TRUE;
				break;
			}
		} else if (uiProVer == Ver3) {
			// check if restart required
			if (sRxFrame.header == V3_START_INDICATION) {
				fw_upload_WaitFor_Req(0);
				continue;
			} else if (fw_upload_WaitFor_Req(0)) {
				if (uiNewLen != 0) {
					if (uiNewError == 0) {
#ifdef DEBUG_PRINT
						PRINT("\n === Succ: REQ = 0xA7, Errcode = 0 ");
#endif
						fw_upload_Send_Ack
							(V3_REQUEST_ACK);
						fw_upload_V3SendLenBytes
							(pFileBuffer, uiNewLen,
							 ulNewOffset);

#ifdef DEBUG_PRINT
						PRINT("\n sent %d bytes..\n",
						      uiNewLen);
#endif
					} else	// NAK,TIMEOUT,INVALID
						// COMMAND...
					{
#ifdef DEBUG_PRINT
						uint8 i;
						PRINT("\n === Fail: REQ = 0xA7, Errcode != 0 ");
						for (i = 0; i < 7; i++) {
							uiErrCnt[i] +=
								(uiNewError >>
								 i) & 0x1;
						}
#endif
						pSerialIf->Flush(iPortID);
						fw_upload_Send_Ack
							(V3_TIMEOUT_ACK);
						if (uiNewError &
						    BT_MIC_FAIL_BIT) {
							change_baudrata_buffer_len
								= 0;
							ulCurrFileSize = 0;
							ulLastOffsetToSend =
								0xFFFF;
						}
					}
				} else {
					/* check if download complete */
					if (uiNewError == 0) {
						fw_upload_Send_Ack
							(V3_REQUEST_ACK);
						bRetVal = TRUE;
						break;
					} else if (uiNewError & BT_MIC_FAIL_BIT) {
#ifdef DEBUG_PRINT
						uiErrCnt[7] += 1;
#endif
						fw_upload_Send_Ack
							(V3_REQUEST_ACK);
						fseek(pFile, 0, SEEK_SET);
						change_baudrata_buffer_len = 0;
						ulCurrFileSize = 0;
						ulLastOffsetToSend = 0xFFFF;
					} else if (uiNewError &
						   TIMEOUT_REC_ACK_BIT) {
						// Send ACK when Timeout &
						// Len=0 .
						fw_upload_Send_Ack
							(V3_TIMEOUT_ACK);
					} else {
						PRINT("\nNon-empty terminating else statement\n");
					}
				}
			}
			PRINT("File downloaded: %8u:%8ld\r", ulCurrFileSize,
			      ulTotalFileSize);
#ifdef DEBUG_FRAME
			if (fw_upload_isDumpFrame()) {
				PRINT("\n");
			}
#endif

		} else {
			PRINT("\nNot downloaded\n");
		}
	}

	if (pFileBuffer != NULL) {
		free(pFileBuffer);
		pFileBuffer = NULL;
	}
	return DOWNLOAD_SUCCESS;
}

/******************************************************************************
 *
 * Name: closeFileorDescriptor
 *
 * Description:
 *   Closes File* or the descriptor pointing to the file
 *
 * Conditions For Use:
 *   File* and fileDescriptor should be pointing to the same resource
 *
 * Arguments:
 *   fileDescriptor:  integer read only descriptor of the file
 *
 * Return Value:
 *   None 
 *
 * Notes:
 *   None.
 *
 ****************************************************************************/
static void
closeFileorDescriptor(int fileDescriptor)
{
	if (pFile != (void *)0) {
		fclose(pFile);
		pFile = NULL;
	}
	if (fileDescriptor != -1) {
		close(fileDescriptor);
	}
}

/******************************************************************************
 *
 * Name: fw_upload_usage
 *
 * Description:
 *   This function display the usage of this program
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   argc:       Number of arguments.
 *   argv:       Arguments table.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static int
fw_upload_usage(int argc, char *argv[], SERIAL_TYPE type)
{
	PRINT("\n");
	PRINT("Utility for downloading firmware (version %s) using Serial/Spi port\n", VERSION);
	PRINT("\n");
	if (type == UART_IF || type == UNKNOWN_IF) {
		PRINT("UART Usage: %s <ComPort> <BaudRate> <FlowControl> <FileName> [Second BaudRate]\n", argv[0]);
		PRINT("--e.g. %s com3 115200 0 uart8997.bin\n", argv[0]);
		PRINT("--e.g. %s /dev/ttyUSB# 115200 0 uart8997.bin\n",
		      argv[0]);
		PRINT("--e.g. %s com3 115200 0 uart9098.bin 3000000\n",
		      argv[0]);
		PRINT("--e.g. %s /dev/ttyUSB# 115200 0 uart9098.bin 3000000\n",
		      argv[0]);
		PRINT("\n");
	}
	PRINT("\n");
	PRINT("Env variable supported\n");
	PRINT("  DUMP_FRAME: dumps frames if greater to 0 (V3 only)\n");
	PRINT("Examples:\n");
#if (OS_TYPE == FW_LOADER_WIN)
	PRINT("  set DUMP_FRAME=0            (default)\n");
	PRINT("  set DUMP_FRAME=1\n");
#endif
#if (OS_TYPE == FW_LOADER_LINUX)
	PRINT("  export DUMP_FRAME=0         (default)\n");
	PRINT("  export DUMP_FRAME=1\n");
#endif
	PRINT("\n");
	return 1;
}

/******************************************************************************
 *
 * Name: fw_upload_parse_args_uart
 *
 * Description:
 *   This function parse the args for uart
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   argc:       Number of arguments.
 *   argv:       Arguments table.
 *
 * Return Value:
 *   pFileName:  pointer to store the name of the file to download
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static char *
fw_upload_parse_args_uart(int argc, char *argv[])
{
	char *pFileName;

	/* Parse mandatory args */
	if (argc < 5)		/* fw_loader <ComPort> <BaudRate> <FlowControl> 
				   <FileName> */
		return NULL;

	/* Parse Arg2 <BaudRate> */
	SerialCfg.uart.uiFirstBaudrate = atoi(argv[2]);
	/* Parse Arg3 <FlowControl> */
	SerialCfg.uart.ucFlowCtrl = atoi(argv[3]);
	/* Parse Arg4 <FileName> */
	pFileName = argv[4];

	/* Check args */
	if (SerialCfg.uart.ucFlowCtrl != 0 && SerialCfg.uart.ucFlowCtrl != 1) {
		PRINT("Usage: fw_loader <ComPort> <BaudRate> <FlowControl> <FileName>, FlowControl should be 0 or 1");
		return NULL;
	}

	/* Fixed option */
	SerialCfg.uart.ucParity = 0;
	SerialCfg.uart.ucStopBits = 1;
	SerialCfg.ucByteSize = sizeof(uint8) * 8;

	/* Parse optional args */
	switch (argc) {
	case 5:		/* fw_loader <ComPort> <BaudRate> <FlowControl> 
				   <FileName> */
		/* Ok, we are done */
		break;
	case 6:		/* fw_loader <ComPort> <BaudRate> <FlowControl> 
				   <FileName> [Second BaudRate] */
		/* Parse Arg5 [Second BaudRate] */
		SerialCfg.uart.uiSecondBaudrate = atoi(argv[5]);
		break;
	default:
		return NULL;
		break;
	}

	/* Print config2 */
	PRINT("BaudRate:          %d\n", SerialCfg.uart.uiFirstBaudrate);
	PRINT("FlowControl:       %d\n", SerialCfg.uart.ucFlowCtrl);
	PRINT("Filename:          %s\n", pFileName);
	if (SerialCfg.uart.uiSecondBaudrate) {
		PRINT("Second BaudRate:  %d\n",
		      SerialCfg.uart.uiSecondBaudrate);
	}

	/* Ok, we are safe */
	return pFileName;
}

/*******************************************************************************
 *
 * Name: main
 *
 * Description:
 *   Main Entry point of the application.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None 
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
int
main(int argc, char **argv)
{
	char *pPortName = NULL;
	char *pFileName = NULL;

	const char *pVersionName = VERSION;
	uint64 endTime;
	uint64 start;
	uint64 cost;
	uint32 ulResult;
	int32 fileDescriptor = -1;

	// Initialize the function pointers.
	fw_upload_io_func_init();
	init_crc8();
	start = fw_upload_GetTime();

	if (sizeof(sRxFrame.ackNakV3) != 1) {
		PRINT("Invalid ackNakV3 pack size %ld\n",
		      sizeof(sRxFrame.ackNakV3));
		return 1;
	}

	if (sizeof(sRxFrame.timeoutV3) != 5) {
		PRINT("Invalid timeoutV3 pack size %ld\n",
		      sizeof(sRxFrame.timeoutV3));
		return 1;
	}

	if (sizeof(sRxFrame.startIndV3) != 4) {
		PRINT("Invalid startIndV3 pack size %ld\n",
		      sizeof(sRxFrame.startIndV3));
		return 1;
	}

	if (sizeof(sRxFrame.dataReqV3) != 9) {
		PRINT("Invalid dataReqV3 pack size %ld\n",
		      sizeof(sRxFrame.dataReqV3));
		return 1;
	}

	/* First get the device name */
	if (argc < 2)
		return fw_upload_usage(argc, argv, UNKNOWN_IF);

	/* Parse Arg1 <Com/Spi Port> */
	pPortName = argv[1];

	/* Next detect the type of device (UART, SPI if needed) */
	pSerialIf = NULL;

#if (OS_TYPE == FW_LOADER_WIN)

	if (sSerialInterfaceWin.Probe(pPortName))
		pSerialIf = &sSerialInterfaceWin;

#elif (OS_TYPE == FW_LOADER_LINUX)
#ifdef (OS_TYPE == FW_LOADER_LINUX)
#ifdef (OS_TYPE == FW_LOADER_LINUX)
#ifdef (OS_TYPE == FW_LOADER_LINUX)

	if (sSerialInterfaceLinuxUart.Probe(pPortName))
		pSerialIf = &sSerialInterfaceLinuxUart;

#else
#error Unknown OS_TYPE
#endif

	if (!pSerialIf) {
		PRINT("Invalid device %s\n", pPortName);
		return 1;
	}

	/* Print config1 */
	PRINT("Protocol:          NXP Proprietary\n");
	PRINT("FW Loader Version: %s\n", pVersionName);
	PRINT("Serial:            %s\n", pSerialIf->name);
	PRINT("Device:            %s\n", pPortName);
	PRINT("DumpFrame:         %s\n",
	      (fw_upload_isDumpFrame())? ("Yes") : ("No"));
	PRINT("Timeout:           %d\n", TIMEOUT_VAL_MILLISEC);

	switch (pSerialIf->type) {
	case UART_IF:
		pFileName = fw_upload_parse_args_uart(argc, argv);
		if (!pFileName)
			return fw_upload_usage(argc, argv, pSerialIf->type);
		break;

	default:		/* Unknown pSerialIf->type */
		return fw_upload_usage(argc, argv, pSerialIf->type);
		break;
	}

#if 0				/* Not working on Win10 */
	fileDescriptor = open(pFileName, O_RDONLY);	// open file
	// descriptor.
	if (fileDescriptor == -1) {
		PRINT("\nError in getting file descriptor");
		retun 1;
	}
	pFile = fdopen(fileDescriptor, "rb");	// open streaming handle.
#else
	pFile = fopen(pFileName, "rb");	// open streaming handle.
#endif
	if (NULL == pFile) {
		perror("fdopen failed");
		return 1;
	}

	do {
		ulResult = fw_upload_FW(pPortName);
		if (ulResult == 0) {
			PRINT("\nDownload Complete\n");
			cost = fw_upload_GetTime() - start;
			PRINT("time:%llu\n", cost);
			if (uiProVer == Ver3 && pSerialIf->type == UART_IF &&
			    SerialCfg.uart.uiSecondBaudrate) {
				fw_upload_DelayInMs(100);
				endTime =
					fw_upload_GetTime() +
					2 * MAX_CTS_TIMEOUT;
			} else {
				fw_upload_DelayInMs(500);
				endTime = fw_upload_GetTime() + MAX_CTS_TIMEOUT;
			}
			do {
				if (!pSerialIf->ComGetCTS(iPortID)) {
					switch (pSerialIf->type) {
					case UART_IF:
						PRINT("CTS is low\n");
						break;
					default:
						PRINT("UNKOWN is low\n");
						break;
					}
					closeFileorDescriptor(fileDescriptor);
					exit((int32) ulResult);
				}
			} while (endTime > fw_upload_GetTime());
			switch (pSerialIf->type) {
			case UART_IF:
				PRINT("CTS is high\n");
				break;
			default:
				PRINT("UNKOWN is high\n");
				break;
			}
			PRINT("Error code is %d\n", ulResult);
			uiReDownload = FALSE;
		} else {
			PRINT("\nDownload Error\n");
			PRINT("Error code is %d\n", ulResult);
			uiReDownload = FALSE;
		}
	} while (uiReDownload);

	if (uiReDownload == FALSE) {
		closeFileorDescriptor(fileDescriptor);
		return (int)ulResult;
	}
	return 0;
}
