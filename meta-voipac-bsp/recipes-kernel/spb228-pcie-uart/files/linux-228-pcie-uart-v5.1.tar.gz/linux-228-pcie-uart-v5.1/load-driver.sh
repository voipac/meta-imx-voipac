#!/bin/bash

INTERFACE=$(cat release-info.txt | grep INTERFACE | sed -e 's/INTERFACE=\([a-zA-Z]\+\).*/\1/')
FWNAME=$(cat release-info.txt | grep -e FWNAME | sed -e 's/FWNAME=\(.*\)/\1/')
PRODUCT=$(cat release-info.txt | grep -e PRODUCT | sed -e 's/PRODUCT=\(.*\)/\1/')

# This is an example on how to load the driver. Refer to the wifi_src or mbt_src
# to have a full list of the module parameters

echo "Loading Wifi driver"
sudo modprobe cfg80211 2> /dev/null
sudo insmod mlan.ko
FWPARAM="fw_name=nxp/$FWNAME"
if [ "$INTERFACE" == "usb" ]; then
	sudo insmod usbfwdnld.ko $FWPARAM
	FWPARAM=""
fi
if [ "$INTERFACE" == "sdio" ]; then
	sudo modprobe mmc_core 2> /dev/null
	INTERFACE="sd"
fi

sudo insmod moal.ko mod_para=nxp/wifi_mod_para.conf

