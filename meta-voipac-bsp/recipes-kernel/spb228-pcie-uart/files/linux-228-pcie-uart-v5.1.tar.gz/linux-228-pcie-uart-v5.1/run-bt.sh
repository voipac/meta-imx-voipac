#!/bin/bash

sudo modprobe hci_uart
sudo hciattach /dev/ttyUSB0 any 115200 flow
sleep 1
sudo hciconfig $(hciconfig | grep -o "hci.") up

if [[ $(hciconfig | grep UP) ]]; then
	exit 0
fi

exit -1
