/** @file   fw_loader_uart.c
 *
 *  @brief  This file contains the functions that implement the Nxp specific
 *          Helper Protocol.
 *
 *  Copyright 2014-2020 NXP
 *
 *  This software file (the File) is distributed by NXP
 *  under the terms of the GNU General Public License Version 2, June 1991
 *  (the License).  You may use, redistribute and/or modify the File in
 *  accordance with the terms and conditions of the License, a copy of which
 *  is available by writing to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA or on the
 *  worldwide web at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt.
 *
 *  THE FILE IS DISTRIBUTED AS-IS, WITHOUT WARRANTY OF ANY KIND, AND THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE
 *  ARE EXPRESSLY DISCLAIMED.  The License provides additional details about
 *  this warranty disclaimer.
 *
 */

/*===================== Include Files ============================================*/
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <setjmp.h>
#include "fw_loader_uart.h"

/*===================== Macros ===================================================*/
// #define VERSION      "M100"
#define MAX_LENGTH 0xffff	// Maximum 2 byte value
/*==================== Typedefs =================================================*/

/*===================== Global Vars ==============================================*/
// Maximum Length that could be asked by the Helper = 2 bytes 
static int8 ucByteBuffer[MAX_LENGTH];

// ID of the current com port
static int32 iPortID = 0;

// Size of the File to be downloaded
static uint32 ulTotalFileSize = 0;

// Current size of the Download
static uint32 ulCurrFileSize = 0;

// Received Header
static uint8 ucRcvdHeader;

jmp_buf resync;			// Protocol restart buffer used in timeout
				// cases.
/*==================== Function Prototypes ======================================*/

/*==================== Coded Procedures =========================================*/
/******************************************************************************
 *
 * Name: fw_upload_io_func_init
 *
 * Description:
 *   This function initializes the IO function pointers.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
void
fw_upload_io_func_init()
{
// Initialize the function pointers depending
// on the OS type.      
#if (OS_TYPE == FW_LOADER_WIN)
	fw_upload_ComReadChar = fw_upload_ComReadChar_Win;
	fw_upload_ComWriteChar = fw_upload_ComWriteChar_Win;
	fw_upload_ComWriteChars = fw_upload_ComWriteChars_Win;
	fw_upload_ComReadChars = fw_upload_ComReadChars_Win;
	fw_upload_init_uart = fw_upload_init_uart_Win;
	fw_upload_DelayInMs = fw_upload_DelayInMs_Win;
	fw_upload_ComGetCTS = fw_upload_ComGetCTS_Win;
#else
	fw_upload_ComReadChar = fw_upload_ComReadChar_Linux;
	fw_upload_ComWriteChar = fw_upload_ComWriteChar_Linux;
	fw_upload_ComWriteChars = fw_upload_ComWriteChars_Linux;
	fw_upload_ComReadChars = fw_upload_ComReadChars_Linux;
	fw_upload_init_uart = fw_upload_init_uart_Linux;
	fw_upload_DelayInMs = fw_upload_DelayInMs_Linux;
	fw_upload_ComGetCTS = fw_upload_ComGetCTS_Linux;
#endif // (OS_TYPE == FW_LOADER_WIN)
}

/******************************************************************************
 *
 * Name: fw_upload_WaitFor_a5()
 *
 * Description:
 *   This function basically waits for reception
 *   of character 0xa5 on UART Rx. If no 0xa5 is 
 *   received, it will kind of busy wait checking for
 *   0xa5.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static void
fw_upload_WaitFor_a5()
{
	uint8 ucDone = 0;	// a5 not Received Yet.
	while (!ucDone) {
		ucRcvdHeader = fw_upload_ComReadChar(iPortID);

		if ((ucRcvdHeader == 0xa5) || (ucRcvdHeader == 0xaa)) {
			ucDone = 1;
		} else {
			fw_upload_DelayInMs(1);
		}
	}
}

/******************************************************************************
 *
 * Name: fw_upload_WaitFor_Len
 *
 * Description:
 *   This function waits to receive the 4 Byte length.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   2 Byte Length to send back to the Helper.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static uint16
fw_upload_WaitFor_Len()
{
	// Length Variables
	uint16 uiLen;
	uint16 uiLenComp;

	// uiLen and uiLenComp are 1's complement of each other. 
	// In such cases, the XOR of uiLen and uiLenComp will be all 1's
	// i.e 0xffff.
	uint16 uiXorOfLen = 0xFFFF;

	// Read the Lengths.
	fw_upload_ComReadChars(iPortID, (char *)&uiLen, 2);
	fw_upload_ComReadChars(iPortID, (char *)&uiLenComp, 2);

	// Check if the length is valid.
	if ((uiLen ^ uiLenComp) == uiXorOfLen)	// All 1's
	{
		// Successful. Send back the ack.
		fw_upload_ComWriteChar(iPortID, 0x5a);

		if (ucRcvdHeader == 0xaa) {
			// We have received the Chip Id and Rev Num that the 
			// helper intended to send. Ignore the received
			// Chip Id, Rev Num and proceed to Download.
			longjmp(resync, 1);
		}
	} else {
		// Failure due to mismatch.  
		fw_upload_ComWriteChar(iPortID, (int8) 0xbf);

		// Start all over again.
		longjmp(resync, 1);
	}
	return uiLen;
}

/******************************************************************************
 *
 * Name: fw_upload_SendLenBytes
 *
 * Description:
 *   This function sends Len bytes to the Helper.    
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static void
fw_upload_SendLenBytes(FILE * pFile, uint16 uiLenToSend)
{
	// There are different cases to handle here. 
	// a) If the LSB of the Length is 0x0, the length
	// to be transmitted is a valid value.
	// b) If the Length is NOT 0x0, this is
	// a request for resend because the CRC of the previous packet did not
	// match.

	// Check if LSB of length is 1.
	if (uiLenToSend & 0x1) {
		// The CRC did not match at the other end.
		// That's why the request to re-send.
		// Since we already have the previous packet's bytes
		// in ucByteBuffer, we can just resend the same.
		// Note: Do not clear the ucByteBuffer 
		uiLenToSend &= ~1;	// Knock of oddness. LSB = 0.
		fw_upload_ComWriteChars(iPortID, ucByteBuffer, uiLenToSend);
	} else {
		uint16 uiNumRead = 0;
		// The length requested by the Helper is equal to the Block
		// sizes used while creating the FW.bin. The usual
		// block sizes are 128, 256, 512.
		// uiLenToSend % 16 == 0. This means the previous packet
		// was error free (CRC ok) or this is the first packet
		// received.
		// We can clear the ucByteBuffer and populate fresh data. 
		memset(ucByteBuffer, 0, sizeof(ucByteBuffer));
		// fread(void *buffer, size_t size, size_t count, FILE *stream)
		uiNumRead = fread(ucByteBuffer, 1, uiLenToSend, pFile);
		ulCurrFileSize += uiNumRead;
		if (uiNumRead != uiLenToSend) {
			printf("\nfread error: Mismatch in Bytes Read\n");
		}
		fw_upload_ComWriteChars(iPortID, ucByteBuffer, uiLenToSend);
	}
}

/******************************************************************************
 *
 * Name: fw_upload_Helper_FW
 *
 * Description:
 *   This function performs the task of FW load over UART.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   Returns the 2-byte Length of data that needs to be sent by the host
 *   to Helper.
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
static BOOLEAN
fw_upload_FW(int8 * pPortName, int32 iBaudRate, uint8 ucFlowCtrl,
	     int8 * pFileName)
{
	FILE *pFile = NULL;
	uint16 uiLenToSend = 0;
	BOOLEAN bRetVal = FALSE;
	int32 result = 0;

	// UART specific variables
	uint8 ucParity = 0;
	uint8 ucStopBits = 1;
	uint8 ucByteSizeinBits = sizeof(uint8) * 8;

	// UART Init
	iPortID =
		fw_upload_init_uart(pPortName, iBaudRate, ucParity, ucStopBits,
				    ucByteSizeinBits, ucFlowCtrl);

	// Open File for reading.
	pFile = fopen(pFileName, "rb");

	if ((iPortID < 0) || (pFile == NULL)) {
		printf("\nPort is not open or file not found\n");
		return bRetVal;
	}
	// Calculate the size of the file to be downloaded. 
	result = fseek(pFile, 0, SEEK_END);
	if (result) {
		printf("\nfseek failed\n");
		return bRetVal;
	}

	ulTotalFileSize = (uint32) ftell(pFile);
	if (!ulTotalFileSize) {
		printf("\nError:Download Size is 0\n");
		return bRetVal;
	}

	fseek(pFile, 0, SEEK_SET);
	ulCurrFileSize = 0;

	// Jump to here in case of protocol resync.
	setjmp(resync);

	// Expecting a packet with 0xa5 Start followed by 4 byte Length.
	while (!bRetVal) {
		// Wait to Receive 0xa5
		fw_upload_WaitFor_a5();

		// Read the 'Length' bytes requested by Helper
		uiLenToSend = fw_upload_WaitFor_Len();

		// If the Length requested is 0, download is complete.
		if (uiLenToSend == 0) {
			printf("File Successfully downloaded: %6d:%6d\r",
			       ulTotalFileSize, ulTotalFileSize);
			bRetVal = TRUE;
			break;
		}
		// Send Length bytes to the Helper.
		fw_upload_SendLenBytes(pFile, uiLenToSend);
		printf("File downloaded: %8d:%8d\r", ulCurrFileSize,
		       ulTotalFileSize);
	}
	return bRetVal;
}

/******************************************************************************
 *
 * Name: main
 *
 * Description:
 *   Main Entry point of the application.
 *
 * Conditions For Use:
 *   None.
 *
 * Arguments:
 *   None.
 *
 * Return Value:
 *   None 
 *
 * Notes:
 *   None.
 *
 *****************************************************************************/
int
main(int argc, char **argv)
{
	int32 iBaudrate;
	int8 *pPortName;
	int8 *pFileName;
	uint8 ucFlowCtrl;

	// Initialize the function pointers.
	fw_upload_io_func_init();

	if (argc != 5) {
		printf("Utility for downloading firmware using COM port\n");
		printf("Usage: :fw_loader <ComPort> <BaudRate> <FlowControl> <FileName>\n");
		printf("--e.g. fw_loader com3 115200 1 uart8790.bin\n");
		printf("--e.g. fw_loader ttyUSB# 115200 1 uart87890.bin\n");
		exit(1);
	}

	pPortName = argv[1];
	iBaudrate = atoi(argv[2]);
	ucFlowCtrl = atoi(argv[3]);
	pFileName = argv[4];

	printf("Protocol: Nxp Proprietary\n");
	printf("ComPort : %s\n", pPortName);
	printf("BaudRate: %d\n", iBaudrate);
	printf("FlowControl: %d\n", ucFlowCtrl);
	printf("Filename: %s\n", pFileName);

	if (fw_upload_FW(pPortName, iBaudrate, ucFlowCtrl, pFileName)) {
		printf("\nDownload Complete\n");
		while (fw_upload_ComGetCTS(iPortID)) ;
		exit(0);
	} else {
		printf("\nDownload Error\n");
		exit(1);
	}
}
