/** @file   fw_loader_uart.h
 *
 *  @brief  This file contains the function prototypes of the Nxp specific
 *          Helper Protocol.
 *
 *  Copyright 2014-2020 NXP
 *
 *  This software file (the File) is distributed by NXP
 *  under the terms of the GNU General Public License Version 2, June 1991
 *  (the License).  You may use, redistribute and/or modify the File in
 *  accordance with the terms and conditions of the License, a copy of which
 *  is available by writing to the Free Software Foundation, Inc.,
 *  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA or on the
 *  worldwide web at http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt.
 *
 *  THE FILE IS DISTRIBUTED AS-IS, WITHOUT WARRANTY OF ANY KIND, AND THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE
 *  ARE EXPRESSLY DISCLAIMED.  The License provides additional details about
 *  this warranty disclaimer.
 *
 */

#ifndef _FW_LOADER_H
#define _FW_LOADER_H
/*===================== Include Files ============================================*/
#include "fw_loader_types.h"

/*===================== Macros ===================================================*/
#define FW_LOADER_WIN   1
#define FW_LOADER_LINUX 0

// Note: _WIN32 or _WIN64 are pre-defined macros
// for Windows applications.
#if defined(_WIN32) || defined(_WIN64)
#define OS_TYPE   FW_LOADER_WIN
#include "fw_loader_io_win.h"
#else // Linux
#define OS_TYPE   FW_LOADER_LINUX
#include "fw_loader_io_linux.h"
#endif // defined (__WIN32) || defined (__WIN64)
/*==================== Typedefs =================================================*/

/*===================== Global Vars ==============================================*/

/*==================== Function Prototypes ======================================*/
int32(*fw_upload_ComReadChar) (int32 iPortID);
int8(*fw_upload_ComWriteChar) (int32 iPortID, int8 iChar);
int8(*fw_upload_ComWriteChars) (int32 iPortID, int8 * pChBuffer, uint32 uiLen);
int32(*fw_upload_ComReadChars) (int32 iPortID, int8 * pChBuffer,
				uint32 uiCount);
int32(*fw_upload_init_uart) (int8 * pPortName, int32 iBaudRate, uint8 ucParity,
			     uint8 ucStopBits, uint8 ucByteSize,
			     uint8 ucFlowCtrl);
void (*fw_upload_DelayInMs) (uint32 uiMs);
int32(*fw_upload_ComGetCTS) (int32 iPortID);

#endif // _FW_LOADER_H
